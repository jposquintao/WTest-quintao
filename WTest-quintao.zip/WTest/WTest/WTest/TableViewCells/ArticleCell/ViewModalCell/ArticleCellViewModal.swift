//
//  ArticleCellViewModal.swift
//  WTest
//
//  Created by João Quintão on 17/04/2022.
//

import Foundation

struct ArticleCellViewModal {
    var title:String
    var author:String
    var summary:String?
}
