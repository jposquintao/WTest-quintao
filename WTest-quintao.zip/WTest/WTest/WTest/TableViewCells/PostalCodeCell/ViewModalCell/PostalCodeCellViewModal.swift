//
//  PostalCodeCellViewModal.swift
//  WTest
//
//  Created by João Quintão on 16/04/2022.
//

import Foundation

struct PostalCodeCellViewModel {
    var numCodPostal:String?
    var extCodPostal:String?
    var desigPostal:String?
}
