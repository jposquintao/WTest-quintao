//
//  RequestPaths.swift
//  WTest
//
//  Created by João Quintão on 17/04/2022.
//

import Foundation

public enum URLREQUEST:String {
    case base10 = "https://5badefb9a65be000146763a4.mockapi.io/mobile/1-0/articles"
    case base11 = "https://5bb1cd166418d70014071c8e.mockapi.io/mobile/1-1/articles"
}

public enum URLLIMIT:String {
    case limit10 = "10"
}
