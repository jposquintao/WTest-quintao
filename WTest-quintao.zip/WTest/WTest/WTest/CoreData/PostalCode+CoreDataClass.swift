//
//  PostalCode+CoreDataClass.swift
//  WTest
//
//  Created by João Quintão on 15/04/2022.
//
//

import Foundation
import CoreData

typealias PostalCodes = [PostalCode]

@objc(PostalCode)
public class PostalCode: NSManagedObject {

}
